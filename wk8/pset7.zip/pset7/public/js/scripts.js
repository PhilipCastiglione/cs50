/**
 * scripts.js
 *
 * Computer Science 50
 * Problem Set 7
 *
 * Global JavaScript, if any.
 */

console.log("Don't worry, I won't write any JavaScript - It's terrible!");
console.log("Refer https://gist.github.com/PhilipCastiglione/368e8360d25719ea345cb4a70a534e18 for details.");