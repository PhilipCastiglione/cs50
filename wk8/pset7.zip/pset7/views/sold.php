<h1>Sale Success</h1>
<p>
    You sold your shares in <?= $symbol ?> for $<?= number_format($proceeds, 2) ?>.
</p>