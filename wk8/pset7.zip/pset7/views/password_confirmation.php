<h1>Password Update Success</h1>
<p>Your password was successfully updated. We won't tell anyone what to - it's pretty embarrassing.</p>