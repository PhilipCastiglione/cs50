<h1>Purchase Success</h1>
<p>
    You bought <?= number_format($number) ?> shares in <?= $symbol ?> for $<?= number_format($cost, 2) ?>.
</p>